package com.byd.voicecontrol;

import android.app.Activity;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final String GPT_URL = "https://us-central1-lusartrans-3fa20.cloudfunctions.net/fuckYourFamily";
    private static final Uri PROVIDER_URI = Uri.parse("content://com.byd.car.server.provider.CarServiceProvider/sync_binder");

    private TextView logView;
    private EditText inputText;
    private SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(30, 30, 30, 30);

        inputText = new EditText(this);
        inputText.setHint("Введите команду: включи кондиционер");
        layout.addView(inputText);

        Button sendBtn = new Button(this);
        sendBtn.setText("Отправить команду");
        sendBtn.setOnClickListener(v -> processCommand(inputText.getText().toString()));
        layout.addView(sendBtn);

        Button voiceBtn = new Button(this);
        voiceBtn.setText("🎤 Голосом");
        voiceBtn.setOnClickListener(v -> startVoiceRecognition());
        layout.addView(voiceBtn);

        Button testBinderBtn = new Button(this);
        testBinderBtn.setText("Тест соединения с CarService");
        testBinderBtn.setOnClickListener(v -> testCarServiceBinder());
        layout.addView(testBinderBtn);

        logView = new TextView(this);
        logView.setText("Готов к работе\n");
        layout.addView(logView);

        setContentView(layout);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    }

    private void log(String msg) {
        runOnUiThread(() -> logView.append(msg + "\n"));
    }

    // ========== ТЕСТ СОЕДИНЕНИЯ С CAR SERVICE ==========
    private void testCarServiceBinder() {
        log("\n--- Тест связи с CarService ---");
        try {
            ContentResolver resolver = getContentResolver();
            // Пробуем получить Binder через ContentProvider
            Bundle result = resolver.call(PROVIDER_URI, "sync_binder", null, null);
            if (result == null) {
                log("call() вернул null — пробуем query()");
                android.database.Cursor c = resolver.query(PROVIDER_URI, null, null, null, null);
                if (c != null) {
                    Bundle extras = c.getExtras();
                    log("query вернул cursor, extras=" + (extras != null ? extras.toString() : "null"));
                    if (extras != null) {
                        IBinder binder = extras.getBinder("binder");
                        log("binder из extras: " + (binder != null ? "ПОЛУЧЕН ✓" : "null"));
                    }
                    c.close();
                } else {
                    log("query вернул null");
                }
            } else {
                log("call() вернул Bundle: " + result.toString());
                IBinder binder = result.getBinder("binder");
                log("binder: " + (binder != null ? "ПОЛУЧЕН ✓" : "null"));
                for (String key : result.keySet()) {
                    log("  key: " + key + " = " + result.get(key));
                }
            }
        } catch (Exception e) {
            log("ОШИБКА: " + e.getMessage());
        }
    }

    // ========== ОБРАБОТКА КОМАНДЫ ==========
    private void processCommand(String userText) {
        if (userText.isEmpty()) return;
        log("\n→ Команда: " + userText);
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... params) {
                try {
                    URL url = new URL(GPT_URL);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);

                    JSONObject req = new JSONObject();
                    req.put("userInput", params[0]);
                    req.put("fuckYou", "");
                    req.put("lang", "pro");

                    OutputStream os = conn.getOutputStream();
                    os.write(req.toString().getBytes("UTF-8"));
                    os.close();

                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    return sb.toString();
                } catch (Exception e) {
                    return "ERROR: " + e.getMessage();
                }
            }

            @Override
            protected void onPostExecute(String response) {
                log("← Сервер: " + response);
                try {
                    JSONObject json = new JSONObject(response);
                    int system = json.getInt("system");
                    long event = json.getLong("event");
                    int state = json.getInt("state");
                    log("system=" + system + " event=" + event + " state=" + state);
                    executeOnCar(system, event, state);
                } catch (Exception e) {
                    log("Parse error: " + e.getMessage());
                }
            }
        }.execute(userText);
    }

    // ========== ВЫПОЛНЕНИЕ НА МАШИНЕ ==========
    private void executeOnCar(int system, long event, int state) {
        log("→ Отправка на машину...");
        try {
            ContentResolver resolver = getContentResolver();

            // Вариант 1: через call() с extras
            Bundle args = new Bundle();
            args.putInt("system", system);
            args.putLong("event", event);
            args.putInt("state", state);

            String[] methodsToTry = {
                "sendCommand", "executeCommand", "executeAtom", "sendAtom",
                "voiceCmd", "executeVoiceCmd", "doCommand", "control"
            };

            for (String method : methodsToTry) {
                try {
                    Bundle res = resolver.call(PROVIDER_URI, method, null, args);
                    if (res != null) {
                        log("✓ " + method + " → " + res.toString());
                    } else {
                        log("  " + method + " → null");
                    }
                } catch (Exception ex) {
                    log("  " + method + " → " + ex.getMessage());
                }
            }
        } catch (Exception e) {
            log("ОШИБКА: " + e.getMessage());
        }
    }

    // ========== ГОЛОСОВОЙ ВВОД ==========
    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                inputText.setText(results.get(0));
                processCommand(results.get(0));
            }
        }
    }
}
