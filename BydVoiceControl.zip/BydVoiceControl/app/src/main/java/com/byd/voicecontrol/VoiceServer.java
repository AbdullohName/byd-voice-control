package com.byd.voicecontrol;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class VoiceServer extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
